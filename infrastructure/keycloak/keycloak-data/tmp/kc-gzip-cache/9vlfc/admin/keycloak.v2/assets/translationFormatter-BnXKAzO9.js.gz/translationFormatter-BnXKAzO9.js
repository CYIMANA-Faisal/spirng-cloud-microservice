import{cg as o}from"./main-CCEN_uGR.js";const e=t=>r=>r&&o(t,r)||"—";export{e as t};
//# sourceMappingURL=translationFormatter-BnXKAzO9.js.map
