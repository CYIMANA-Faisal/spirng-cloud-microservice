import{c as s}from"./main-CCEN_uGR.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-BDASBPeY.js.map
